import { initialize } from './init.js';

initialize();