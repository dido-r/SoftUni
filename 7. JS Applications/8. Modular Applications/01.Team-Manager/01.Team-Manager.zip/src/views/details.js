import { html, nothing } from '../../node_modules/lit-html/lit-html.js';
import { get } from '../api/api.js';
import { navBarView} from './nav.js';

const userId = sessionStorage.getItem('userId');

let template = (data, members) => html`<section id="team-home">
<article class="layout">
    <img src="${data.logoUrl}" class="team-logo left-col">
    <div class="tm-preview">
        <h2>${data.name}</h2>
        <p>${data.description}</p>
        <span class="details">${members.length} Members</span>
        <div>
            ${ userId === data._ownerId ? html`<a href="/edit/${data._id}" class="action">Edit team</a>` : nothing}
            ${ 1 > 0 ? console.log(isMember(data)) : nothing}
            ${ userId !== data._ownerId ? html`<a href="#" class="action invert">Leave team</a>` : nothing}
            
            <!-- Membership pending. <a href="#">Cancel request</a> -->
        </div>
    </div>
    <div class="pad-large">
        <h3>Members</h3>
        <ul class="tm-members"> 
           ${members.filter(x => x.status === 'member').map(x => templateMembers(x, data))}
        </ul>
    </div>
    ${ userId === data._ownerId ? html`<div class="pad-large">
        <h3>Membership Requests</h3>
        <ul class="tm-members">
            ${members.find(x => x.status === 'pending') ? members.filter(x => x.status === 'pending').map(templatePending) : html`<p>No pending requests.</p>`}
        </ul>
    </div>` : nothing}
</article>
</section>`;

let templateMembers = (member, data) => html`<li>${member.user.username} ${ (userId === data._ownerId && member._ownerId !== userId) ? html`<a href="#" class="tm-control action">Remove from team</a>` : nothing}</li>`;
let templatePending = (member) => html`<li>${member.user.username} <a href="#" class="tm-control action">Approve</a><a href="#" class="tm-control action">Decline</a></li>`;

export async function detailView(ctx){

    navBarView(ctx);
    let data = await get(`/data/teams/${ctx.params.id}`);
    let members = await teamMembers(ctx);
    ctx.render(template(data, members));
}

async function teamMembers(ctx){

    return await get(`/data/members?where=teamId%3D%22${ctx.params.id}%22&load=user%3D_ownerId%3Ausers`);
}

async function isMember(data){

    let res = await get(`/data/members?where=${encodeURIComponent(`_ownerId="${userId}"&teamId="${data._id}"`)}`);
    return res;
}