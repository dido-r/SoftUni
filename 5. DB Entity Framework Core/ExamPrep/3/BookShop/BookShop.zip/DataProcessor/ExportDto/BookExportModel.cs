﻿namespace BookShop.DataProcessor.ExportDto
{
    public class BookExportModel
    {
        public string BookName { get; set; }

        public string BookPrice { get; set; }
    }
}
