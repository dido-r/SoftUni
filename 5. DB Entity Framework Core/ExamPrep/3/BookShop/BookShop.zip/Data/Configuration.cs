﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-I51906\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}