﻿using CarDealer.Data;
using CarDealer.Dto.Export;
using CarDealer.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var context = new CarDealerContext();
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            Console.WriteLine(GetTotalSalesByCustomer(context));
        }

        public static string GetTotalSalesByCustomer(CarDealerContext context)
        {
            var customer = context
                 .Customers
                 .Where(x => x.Sales.Count > 0)
                 .Select(x => new CustomerWithSaleOutput
                 {
                     Name = x.Name,
                     BoughtCars = x.Sales.Count(),
                     SpentMoney = x.Sales.Select(y => y.Car).SelectMany(x => x.PartCars).Select(x => x.Part.Price).Sum()
                 })
                 .OrderByDescending(x => x.SpentMoney)
                 .ToArray();

            var serialiser = new XmlSerializer(typeof(CustomerWithSaleOutput[]), new XmlRootAttribute("customers"));
            var writer = new StringWriter();
            var settings = new XmlSerializerNamespaces();
            settings.Add("", "");
            serialiser.Serialize(writer, customer, settings);

            return writer.ToString();
        }
    }
}