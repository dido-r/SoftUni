﻿using System;
using System.Linq;

namespace DateModifier
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string first = Console.ReadLine();
            string second = Console.ReadLine();
            DateModifier date = new DateModifier();
            var result = date.DaysCalcule(first, second);
            Console.WriteLine(result);
        }
    }
}
