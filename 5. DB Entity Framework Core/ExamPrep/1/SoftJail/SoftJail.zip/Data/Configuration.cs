﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-I51906\SQLEXPRESS;Database=SoftJail;Trusted_Connection=True";
    }
}
