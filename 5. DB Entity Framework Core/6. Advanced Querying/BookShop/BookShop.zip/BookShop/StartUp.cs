﻿namespace BookShop
{
    using Data;
    using System.Linq;
    using System;
    using System.Text;
    using Microsoft.EntityFrameworkCore;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);

            Console.WriteLine(RemoveBooks(db));
        }
        public static int RemoveBooks(BookShopContext context)
        {
            var books = context
                .Books
                .Where(x => x.Copies < 4200)
                .ToList();

            int count = 0;

            foreach (var book in books)
            {
                if (context.Books.Contains(book))
                {
                    context.Remove(book);
                    count++;
                }
            }

            context.SaveChanges();

            return count;
        }
    }
}
