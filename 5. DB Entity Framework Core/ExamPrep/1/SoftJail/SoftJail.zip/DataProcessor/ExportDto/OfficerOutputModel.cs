﻿namespace SoftJail.DataProcessor.ExportDto
{
    public class OfficerOutputModel
    {
        public string OfficerName { get; set; }
        public string Department { get; set; }
    }
}
