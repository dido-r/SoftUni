﻿namespace BookShop.DataProcessor.ImportDto
{
    public class BookListImportModel
    {
        public string Id { get; set; }
    }
}
