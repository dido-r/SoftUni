﻿namespace SpaceStation.Models.Astronauts
{
    class Geodesist : Astronaut
    {
        public Geodesist(string name) : base(name, 50)
        {
        }
    }
}
