﻿namespace SpaceStation.Models.Astronauts
{
    class Meteorologist : Astronaut
    {
        public Meteorologist(string name) : base(name, 90)
        {
        }
    }
}
