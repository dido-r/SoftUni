﻿// ReSharper disable InconsistentNaming
namespace ORMFundamentals_LiveDemo
{
    public class Config
    {
        public const string ConnectionString =
            @"Server=.;Database=SoftUniCodeFirst;Integrated Security=True;";
    }
}
